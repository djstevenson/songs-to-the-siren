[![Build Status](https://travis-ci.org/perltidy/perltidy.svg?branch=master)](https://travis-ci.org/perltidy/perltidy)

# Welcome to Perltidy

Perltidy is a tool to indent and reformat scripts written in Perl.

Perltidy is free software released under the GNU General Public
License -- please see the included file "COPYING" for details.

Documentation can be found at the web site [at GitHub](https://perltidy.github.io/perltidy/) 
or [at Sourceforge](http://perltidy.sourceforge.net)
or [at metacpan](https://metacpan.org/pod/distribution/Perl-Tidy/bin/perltidy)

A copy of the web site is contained in the docs folder of the distribution.

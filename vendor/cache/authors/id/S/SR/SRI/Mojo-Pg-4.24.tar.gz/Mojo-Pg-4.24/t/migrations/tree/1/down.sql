DROP TABLE IF EXISTS migration_test_three;

CREATE TABLE IF NOT EXISTS mojo_migrations_upgrading (baz VARCHAR(255));

CREATE TABLE IF NOT EXISTS migration_test_three (baz VARCHAR(255));

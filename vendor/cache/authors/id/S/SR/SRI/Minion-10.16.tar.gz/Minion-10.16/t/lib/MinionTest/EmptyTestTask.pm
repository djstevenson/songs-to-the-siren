package MinionTest::EmptyTestTask;
use Mojo::Base 'Minion::Job';

1;

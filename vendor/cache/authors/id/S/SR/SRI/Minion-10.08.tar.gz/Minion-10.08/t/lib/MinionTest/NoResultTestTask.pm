package MinionTest::NoResultTestTask;
use Mojo::Base 'MinionTest::AddTestTask';

sub run { }

1;

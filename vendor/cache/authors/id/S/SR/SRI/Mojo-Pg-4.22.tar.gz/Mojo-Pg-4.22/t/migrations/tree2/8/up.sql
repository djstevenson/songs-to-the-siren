CREATE TABLE IF NOT EXISTS mojo_migrations_test8 (foo VARCHAR(255));

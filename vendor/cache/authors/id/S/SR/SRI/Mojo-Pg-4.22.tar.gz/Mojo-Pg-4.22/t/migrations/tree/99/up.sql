CREATE TABLE IF NOT EXISTS migration_test_luft_balloons (baz VARCHAR(255));

INSERT INTO migration_test_three VALUES ('just');
INSERT INTO migration_test_three VALUES ('works ♥');

CREATE TABLE IF NOT EXISTS mojo_migrations_test9 (foo VARCHAR(255));

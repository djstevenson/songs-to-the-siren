package MinionTest::BadTestTask;
use Mojo::Base -base;

1;

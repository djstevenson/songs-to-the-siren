package MinionTest::SyntaxErrorTestTask;
use Mojo::Base 'Minion::Job';

sub run {

1;

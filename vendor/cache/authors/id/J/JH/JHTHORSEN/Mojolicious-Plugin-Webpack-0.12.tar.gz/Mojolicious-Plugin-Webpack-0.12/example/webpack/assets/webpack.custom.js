module.exports = function(config) {
  config.entry = {
    'example': './assets/js/app.js',
  };
};

(function(w, d) {
  console.log("Hey!");
})(window, document);

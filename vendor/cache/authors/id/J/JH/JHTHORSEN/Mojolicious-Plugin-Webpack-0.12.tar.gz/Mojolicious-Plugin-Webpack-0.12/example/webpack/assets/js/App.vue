<template>
  <div>
    <h1>{{h1}}</h1>
    <p>I am a vue app.</p>
  </div>
</template>

<script>
export default {
  data() {
    return {h1: "Hello world!"};
  }
};
</script>

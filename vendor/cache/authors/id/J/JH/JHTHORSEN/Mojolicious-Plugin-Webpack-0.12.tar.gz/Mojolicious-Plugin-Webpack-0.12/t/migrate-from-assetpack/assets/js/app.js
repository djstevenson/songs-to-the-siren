(function(w, d) {
  console.log("app.js");
})(window, document);

import { subtract } from './calc';

console.log(subtract(44, 2));

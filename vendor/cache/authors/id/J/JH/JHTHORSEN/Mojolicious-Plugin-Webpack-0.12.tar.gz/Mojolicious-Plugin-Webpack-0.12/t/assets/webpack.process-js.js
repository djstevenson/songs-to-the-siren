module.exports = function(config) {
  config.entry = {
    'add': './assets/js/process-js-add.js',
    'subtract': './assets/js/process-js-subtract.js'
  };
};

module.exports = function(config) {
  config.entry = {
    'myapp': './assets/myapp.js'
  };
};

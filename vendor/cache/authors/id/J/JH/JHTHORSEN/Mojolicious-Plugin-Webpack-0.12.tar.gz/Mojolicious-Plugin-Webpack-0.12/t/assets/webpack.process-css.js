module.exports = function(config) {
  config.entry = {
    'basic': './assets/css/basic.css',
  };
};

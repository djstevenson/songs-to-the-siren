module.exports = function(config) {
  config.entry = {
    'basic': './assets/sass/basic.scss',
  };
};

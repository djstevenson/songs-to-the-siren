import { add } from './calc';

console.log(add(41, 2));

package t::Rand;

rand(1);

1;

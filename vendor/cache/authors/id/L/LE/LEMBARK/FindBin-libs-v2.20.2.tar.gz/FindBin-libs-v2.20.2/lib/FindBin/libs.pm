package libs.pm;

die "Please use Makefile.PL to detect the correct module version.\n";
__END__
=head1 Placeholder for real file copied via Makefile.pl

If you see this then Makefile.PL was not run or failed to find 
a working perl executable in order to detect the version, or the
perl on your path is older than 5.8.
